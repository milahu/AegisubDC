lfs = require 'aegisub.lfs'
return lfs
